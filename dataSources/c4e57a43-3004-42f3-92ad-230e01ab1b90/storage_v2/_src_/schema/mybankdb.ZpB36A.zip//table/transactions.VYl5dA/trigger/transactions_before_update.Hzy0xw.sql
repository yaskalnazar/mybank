create definer = root@localhost trigger transactions_BEFORE_UPDATE
    before UPDATE
    on transactions
    for each row
BEGIN
	IF (NEW.`transaction_amount` < 0) THEN
		SIGNAL SQLSTATE '12002'
        SET MESSAGE_TEXT = 'negative transaction amount during update';
		END IF;
END;

