create definer = root@localhost trigger accounts_BEFORE_UPDATE
    before UPDATE
    on accounts
    for each row
BEGIN
	IF (OLD.`credit_limit` IS NOT NULL) then
		IF (NEW.`balance` < 0 - OLD.`credit_limit`) THEN
		SIGNAL SQLSTATE '12001'
        SET MESSAGE_TEXT = 'negative account balance during update';
		END IF;
	ELSE 
		IF (NEW.`balance` < 0) THEN
		SIGNAL SQLSTATE '12001'
        SET MESSAGE_TEXT = 'negative account balance during update';
		END IF;
    END IF;
END;

