create definer = root@localhost trigger payments_BEFORE_INSERT
    before INSERT
    on payments
    for each row
BEGIN
	IF (NEW.`amount` < 0) THEN
		SIGNAL SQLSTATE '10000'
        SET MESSAGE_TEXT = 'negative amount during insert';
		END IF;
END;

