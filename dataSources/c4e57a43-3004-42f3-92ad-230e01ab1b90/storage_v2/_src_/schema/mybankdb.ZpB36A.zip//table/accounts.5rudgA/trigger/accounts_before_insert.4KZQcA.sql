create definer = root@localhost trigger accounts_BEFORE_INSERT
    before INSERT
    on accounts
    for each row
BEGIN
	IF (NEW.`credit_limit` IS NOT NULL) then
		IF (NEW.`balance` < 0 - NEW.`credit_limit`) THEN
		SIGNAL SQLSTATE '12001'
        SET MESSAGE_TEXT = 'negative account balance during insert';
		END IF;
	ELSE 
		IF (NEW.`balance` < 0) THEN
		SIGNAL SQLSTATE '12001'
        SET MESSAGE_TEXT = 'negative account balance during insert';
		END IF;
    END IF;
END;

