create definer = root@localhost trigger payments_BEFORE_UPDATE
    before UPDATE
    on payments
    for each row
BEGIN
	IF (NEW.`amount` < 0) THEN
		SIGNAL SQLSTATE '10000'
        SET MESSAGE_TEXT = 'negative amount during update';
		END IF;
END;

